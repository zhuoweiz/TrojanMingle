var email = $('#_signinEmailID').val();
var pw = $('#_signinPwID').val();

var requeststr = "email=" + email + "&pw=" + pw;

var signinxhttp = new XMLHttpRequest();
signinxhttp.open("POST","/Signin?", true);
signinxhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
signinxhttp.send(requeststr);