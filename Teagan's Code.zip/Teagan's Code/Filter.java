package user;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Filter")
public class Filter extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("In the sr_servlet------------------->");
       //get filters
		String age1 = request.getParameter("age1");
		String age2 = request.getParameter("age2");
		String gender = request.getParameter("gender");
		String major = request.getParameter("major");
		String idealDate = request.getParameter("idealDate");
	    String yr = request.getParameter("yr");
	    
	    //just making sure the user isn't a guest
	    boolean guest = Boolean.parseBoolean(request.getParameter("guest"));
	    int userID = Integer.parseInt(request.getParameter("userID"));
	    
		System.out.println("major= " + major);
		System.out.println("age1= " + age1);
		System.out.println("gender= " + gender);
		
		PrintWriter out = response.getWriter();
		
		response.setContentType("text/html");
        
		Connection conn = null;
	    ResultSet rs = null;
	    ResultSet friends = null;

		PreparedStatement preparedStatement = null;
		String query = "";
		String insertTableSQL = "";
		boolean flag = false;
							
	    try {
	    	Class.forName("com.mysql.jdbc.Driver");
	        conn = DriverManager.getConnection("jdbc:mysql://localhost/trojanmingle?user=root&password=root&useSSL=false&AllowPublicKeyRetrieval=True");
	        
	        //search users in database based on filters
	        insertTableSQL = "SELECT * from users where major = '" + major + "' and age = '" + age1  + "' and gender= '" + gender + "'";
	        System.out.println(insertTableSQL);
	        query = "SELECT * from users where ";
	        //ArrayList<String> conditions = new ArrayList<String>();
	        if(!gender.equals("Choose...")) {
	        	query += "gender = '" + gender + "'";
	        	flag = true;
	        }
	        if(!age1.equals("Age..") &&  !age2.equals("Age..")) {
	        	if(flag) {
	        	 query += " and age between '" + age1 + "'and'" + age2 + "'";
	        	} else {
	        		query += " age between '" + age1 + "'and'" + age2 + "'";
	        		flag = true;
	        	}
	        } else if(!age1.equals("Age..") &&  age2.equals("Age..")) {
	        	if(flag) {
	        	 query += " and age  = '" + age1 + "'";
	        	} else {
	        		 query += " age  = '" + age1 + "'";
	        		 flag = true;
	        	}
	        } else if(age1.equals("Age..") &&  !age2.equals("Age..")) {
	        	if(flag) {
		        	 query += " and age  = '" + age2 + "'";
		        	} else {
		        		 query += " age  = '" + age2 + "'";
		        		 flag = true;
		        	}
	        }
	        if(!major.equals("Choose...")) {
	        	if(flag) {
		        	 query += " and major  = '" + major + "'";
		        } else {
	        		 query += " major  = '" + major + "'";
	        		 flag = true;
		        }
	        }
	        if(!yr.equals("Choose...")) {
	        	if(flag) {
		        	 query += " and yr  = '" + yr + "'";
		        } else {
	        		 query += " yr  = '" + yr + "'";
	        		 flag = true;
		        }
	        }
	        if(!idealDate.equals("Choose...")) {
	        	if(flag) {
		        	 query += " and idealDate  = '" + idealDate + "'";
		        } else {
	        		 query += " idealDate  = '" + idealDate + "'";
	        		 flag = true;
		        }
	        }
	        System.out.println("Test: "+ query);
	       
	        //TEAGAN ADDED FOR NOT SHOWING YOURSELF PURPOSES
	        if(flag) {
	        	query += " AND userID!="+userID+" ;";
	        }
	        else {
	        	query += " userID!="+userID+" ;";
	        }
	        //
	        

	        preparedStatement = conn.prepareStatement(query);  
			rs = preparedStatement.executeQuery();
			
			ArrayList<User> results = new ArrayList<User>();
	        
			if(!rs.next()) {
	        	//no users match the criteria
	        	String result = "No results matching your criteria";
	        	out.println("<figcaption id = \"cap\">" + result  + "</figcaption>");	
	        	
	        	//just use AJAX call on Browse page to show this in the innerHTML
	        
	        	
	        } else { //there exists at least one user matching the criteria
	        
                rs.beforeFirst();
                
		        System.out.println("Here");
		        while (rs.next()) {
		        	User insert = new User(rs.getInt("userID"), rs.getString("fname"), 
		        			rs.getString("picLink"), rs.getString("bio"), rs.getString("major"), 
		        			rs.getString("standing"), rs.getString("gender"), rs.getString("idealDate"), rs.getInt("age"), rs.getInt("yr"));
        	        results.add(insert);
        	        System.out.println(rs.getString("fname"));
		        	
		        }
		        
		        
		        
	        }
			
			//all the parameters browse.jsp needs
	        request.setAttribute("users", results); //will be empty if no results
	        request.setAttribute("guest", false);
	        request.setAttribute("userID", userID);
	       			
			System.out.println("passed results...");
			
			
	        
	    } catch (SQLException sqle) {
	        System.out.println("Here1");
	        
	    	System.out.println (sqle.getMessage());
	    } catch (ClassNotFoundException cnfe) {
	        System.out.println("Here2");	    	
	    	System.out.println (cnfe.getMessage());
	    } finally {
	    	try {
	    		if (rs != null) {
	    			rs.close();
	    		}
	    		if (preparedStatement != null) {
	    			preparedStatement.close();
	    		}
	    		if (conn != null) {
	    			conn.close();
	    		}
	    	} catch (SQLException sqle) {
		        System.out.println("Here3");
	    		System.out.println(sqle.getMessage());
	    	}
	    }
	    
	    
	    //REDIRECT BACK TO BROWSE PAGE
	  		String nextJSP = "/newbrowse.jsp";
	  		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(nextJSP);
	  		dispatcher.forward(request, response);
	    
	    
	}
	
	
}
