

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SignIn
 */
@WebServlet("/SignIn")
public class SignIn extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SignIn() {
        super();
        // TODO Auto-generated constructor stub
    }

	
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	System.out.println("Trying to login");
    	String userName = request.getParameter("userName");
    	String password = request.getParameter("pw");
    	
    	Connection conn = null;
	    Statement st = null;
	    ResultSet rs = null;
	    PreparedStatement ps = null;
	    
	    try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost/trojanmingle?user=root&password=201&useSSL=false");
			System.out.println("Found the driver");
			
			ps = conn.prepareStatement("SELECT userID FROM Users WHERE email=? AND hashedpw=?");
			ps.setString(1, userName+"@usc.edu");
			ps.setString(2, password);
			
			System.out.println(userName);
			System.out.println(password);
			
			rs = ps.executeQuery();
			
			if (rs.next()) {
				// XXX
				// front end fixes, 1) write up 2) form action stuff
				// successfully logged in
				// Session storage and multithreading 
				System.out.println("Logged in!");
			} else {
				System.out.println("Not logged in!");
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	    
	    
    }

}
