import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import user.User;

@WebServlet("/BrowseServ")
public class BrowseServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		response.setContentType("text/html");
        
		Connection conn = null;
	    ResultSet rs = null;
	    ResultSet friends = null;

		PreparedStatement preparedStatement = null;
		String insertTableSQL = "";
	    	
	    try {
	    	
	    	Class.forName("com.mysql.jdbc.Driver");
	        conn = DriverManager.getConnection("jdbc:mysql://localhost/trojanmingle?user=root&password=Outrigger10!&useSSL=false&AllowPublicKeyRetrieval=True");
	        
	        ArrayList<User> results = new ArrayList<User>();
	        
	        //search users in database based on filters
	        for(int i = 0; i <10; i++) {
	        	insertTableSQL = "SELECT * from users where userID = '" + i + "'";
	        	preparedStatement = conn.prepareStatement(insertTableSQL);  
				rs = preparedStatement.executeQuery();
				  while (rs.next()) {
			        	String potential = rs.getString("fname");
			        
			        	System.out.println(rs.getString("fname"));
			        	User insert = new User(rs.getInt("userID"), rs.getString("fname"), 
			        			rs.getString("picLink"), rs.getString("bio"), rs.getString("major"), 
			        			rs.getString("standing"), rs.getString("gender"), rs.getString("idealDate"), rs.getInt("age"), rs.getInt("yr"));
			        	results.add(insert);
			        }
	        }
	        
	        System.out.println("test");	
	        request.setAttribute("result", results);
			
	        
	    } catch (SQLException sqle) {
	        System.out.println("Here1");	    	
	    	System.out.println (sqle.getMessage());
	    } catch (ClassNotFoundException cnfe) {
	        System.out.println("Here2");	    	
	    	System.out.println (cnfe.getMessage());
	    } finally {
	    	try {
	    		if (rs != null) {
	    			rs.close();
	    		}
	    		if (preparedStatement != null) {
	    			preparedStatement.close();
	    		}
	    		if (conn != null) {
	    			conn.close();
	    		}
	    	} catch (SQLException sqle) {
		        System.out.println("Here3");
	    		System.out.println(sqle.getMessage());
	    	}
	    }
	}
	
	
}